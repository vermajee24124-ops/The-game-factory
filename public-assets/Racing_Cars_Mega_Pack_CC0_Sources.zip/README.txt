Racing Cars Mega Pack - public CC0 source reconstruction.
Contains the verified CC0 source archives used by the supplied pack.
This is not a byte-for-byte copy of the original uploaded derived ZIP.
