All included source packs are documented as CC0-1.0 on their public source pages.
See source_manifest.json in the parent Turbo Rush bundle for source links.
